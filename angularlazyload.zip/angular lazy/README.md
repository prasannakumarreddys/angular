# Lazy Loading Demo for Angular 4

Lazy Loading Components in Angular.


![](https://firebasestorage.googleapis.com/v0/b/firestarter-96e46.appspot.com/o/assets%2Fgif-lazy.gif?alt=media&token=17f4a035-0c06-4583-a2f2-a3f2b85eb7be)


Watch the full [Lazy Loading Video Lesson](https://angularfirebase.com/lessons/how-to-lazy-load-components-in-angular-4-in-three-steps/). 
